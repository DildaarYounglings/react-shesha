import React,{useRef,useState} from 'react';
import {NavLink} from 'react-router-dom';

export const TopNav = () => {
  const navigation = [
    {name:'Home',href:'/'},
    {name:'Lessons',href:'/lessons'},
    {name:'Live Lessons',href:'/liveLessons'},
    {name:'Ingredients',href:'/ingredient'},
  ]

  return (<>
    <style>
      {/*begining of all css for TopNav.js component*/
      `@keyframes TopNav{
        from{transform:translateX(-200%);opacity:0;}
        to{transform:translateX(0px);opacity:1}
      }
      .TopNav{
        display: flex;
        position: sticky;top:0px;z-index:1;
        border-bottom:solid black 1px;
        background-color:white;
        width:100%;
        animation: TopNav ease-in-out 4s;
      }
      .TopNav_logo{
        height:65px
      }
      .TopNav_a{
        height:40px;
        cursor: pointer;
        position: relative;
        bottom:-20px;
        margin-left:10%;
        font-size:1.3rem;
        color: black;
        text-decoration: none;
      }
      .active{
        height:40px;
        cursor: pointer;
        position: relative;
        bottom:-20px;
        margin-left:10%;
        font-size:1.3rem;
        color: black;
        border-bottom:4px solid green;
      }
      .search_icon{
        position: relative;left:-5px;
        background-color:white;
        border:none;
        margin-left: auto;
      }
      .logIn{
        position: relative;bottom:-20px;
        background-color:white;
        border:solid black 1.5px;
        font-size:1.09rem;
      }
      .logIn_a{
        width:fit-content; height:fit-content;
        background-color:white;
        margin-right:10%;
      }`
/*end of all css for TopNav.js component*/}
    </style>
    <nav className="TopNav">
        <img className="TopNav_logo" src={"images/shesha_logo.png"} alt=""/>
        {navigation.map((item)=>(
          <NavLink key={item.name} to={item.href} className={ ({isActive}) => {return `TopNav_a ${isActive? 'TopNav_a active': ''}`}}>{item.name}</NavLink>
        ))}
        <button className="search_icon" type="button"><img src={"images/search_icon.png"} className="logo" alt=""/></button>
        <a className="logIn_a">
          <button className="logIn"><NavLink to="">Login</NavLink></button>
        </a>
    </nav>
    </>
  )
}
