import React,{useRef} from 'react';
import { TopNav } from '../components/TopNav';
import {NavLink} from 'react-router-dom';
const API_KEY = "7c65001c662c4d7f874c1b64bdf0a2de";

export const Recipes = (props) => {
    //main variables
    const API_URL_normal = `https://api.spoonacular.com/recipes/complexSearch?query=curry&number=9&apiKey=7c65001c662c4d7f874c1b64bdf0a2de`;
    let ApiUrl_searchFeature =`https://api.spoonacular.com/recipes/complexSearch?query=${props.query}&number=${9}&apiKey=${API_KEY}&includeNutrition=true`
    const videoEl = useRef();

    const handleSearch = async(e) => {
        e.preventDefault();videoEl.current.play();props.setIsDoneLoading("loading");
        let myTimeout = setTimeout(() => {
            props.setIsDoneLoading("");
            clearTimeout(myTimeout);
        }, 2000);
        // const recipeData = await fetch(`https://api.spoonacular.com/recipes/complexSearch?query=${props.query}&number=9&apiKey=${API_KEY}`).then( response => response.json() ).then( jsonData => jsonData.results);
        // props.setRecipes(recipeData);
        // props.setQuery("");
        // console.log(recipeData);
    }
  return (
    <section className={`Recipes`}>
        <TopNav/>
        <form style={{marginBottom:"60px"}} onSubmit={handleSearch}>
            <input
            className={`RecipeSearchBar`} 
            type="text" 
            value={props.query}
            onChange={(e) => {console.log(props.query);props.setQuery(e.target.value);}}/>
            <button className={`RecipeSearchButton`} type="submit">search</button>
        </form>
        <div className={`${(props.isDoneLoading === "loading")? "LoadingScreen" : "DisplayNone"}`}>
            <video ref={videoEl} src={`loading.mp4`} loop="true" className={`${(props.isDoneLoading === "loading")? "LoadingScreen" : "DisplayNone"}`}/>
        </div>
        <div className={`RecipesContainer`}>
            <ul className={`RecipesList`}>
                {props.recipes && props.recipes.map((item)=>(
                <li className={`RecipeListItem`} key={item.id}>
                    <img className={`RecipeListImg`} src={item.image} alt={item.title}/>
                    <h3>{item.title}</h3><NavLink to={`/recipesMethods/${item.title}`} style={{textDecoration:"none",color:"black"}}>click to view method</NavLink>
                </li>
            ))}
            </ul>
        </div>
    </section>
  )
}